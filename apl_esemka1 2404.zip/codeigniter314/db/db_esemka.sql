-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2017 at 11:02 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_esemka`
--
CREATE DATABASE IF NOT EXISTS `db_esemka` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_esemka`;

-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE IF NOT EXISTS `guru` (
  `kode_guru` varchar(6) NOT NULL,
  `nip` varchar(15) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` enum('Laki - Laki','Perempuan','','') NOT NULL,
  `agama` enum('Islam','','','') NOT NULL,
  `pendidikan` enum('S1','S2','','') NOT NULL,
  `no_tlp` varchar(15) NOT NULL,
  `alamat` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`kode_guru`, `nip`, `nama`, `tgl_lahir`, `jenis_kelamin`, `agama`, `pendidikan`, `no_tlp`, `alamat`) VALUES
('GG0001', '99999', 'as', '2017-04-06', 'Laki - Laki', 'Islam', 'S1', '021234567', 'asdad'),
('GG0002', '9999999999', 'aaaaaaa', '2017-04-02', 'Laki - Laki', 'Islam', 'S1', '999999999', 'aaaaa'),
('GG0003', '8998989898', 'sajksnjkasn', '2017-04-18', 'Laki - Laki', 'Islam', 'S1', '1212133', 'dda');

-- --------------------------------------------------------

--
-- Table structure for table `pelajaran`
--

CREATE TABLE IF NOT EXISTS `pelajaran` (
  `kd_pelajaran` varchar(12) NOT NULL,
  `mata_pelajaran` varchar(20) NOT NULL,
  `kkm` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelajaran`
--

INSERT INTO `pelajaran` (`kd_pelajaran`, `mata_pelajaran`, `kkm`) VALUES
('PL0001', 'Matematika', 70),
('PL0002', 'B.Indonesia', 73),
('PL0003', 'IPS', 72),
('PL0004', 'IPA', 78),
('PL0005', 'B.Inggris', 74);

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id_siswa` varchar(10) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `tempat_lahir` varchar(20) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `agama` enum('Islam','Katolik','Kristen Protestan','Hindu','Budha') NOT NULL,
  `jenis_kelamin` enum('Laki - Laki','Perempuan','','') NOT NULL,
  `alamat` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nis`, `nama`, `tempat_lahir`, `tgl_lahir`, `agama`, `jenis_kelamin`, `alamat`) VALUES
('SI0001', '999999999', 'Yanuar', 'Bekasi', '1997-01-26', 'Islam', 'Laki - Laki', 'Jln.Raya Hankam'),
('SI0003', '99999999', 'aaaaaaa', 'aaaa', '2017-04-05', 'Islam', 'Laki - Laki', 'dddddd'),
('SI0006', '999999999', 'aaaaaaaa', 'cxcxcx', '2017-04-04', 'Islam', 'Laki - Laki', 'sadddd'),
('SI0007', 'sd', 'dddds', 'dasa', '2017-04-05', 'Islam', 'Laki - Laki', 'dds'),
('SI0008', '99999', 'a', 'sss', '2017-04-22', 'Islam', 'Laki - Laki', 'ssd');

-- --------------------------------------------------------

--
-- Table structure for table `walikelas`
--

CREATE TABLE IF NOT EXISTS `walikelas` (
  `kode` int(2) NOT NULL,
  `kode_guru` varchar(6) NOT NULL,
  `kelas` enum('X','XI','XII','') NOT NULL,
  `jurusan` enum('Otomotif','Kelistrikan','Penerbangan','') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `walikelas`
--

INSERT INTO `walikelas` (`kode`, `kode_guru`, `kelas`, `jurusan`) VALUES
(1, 'GG0001', 'X', 'Otomotif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`kode_guru`);

--
-- Indexes for table `pelajaran`
--
ALTER TABLE `pelajaran`
  ADD PRIMARY KEY (`kd_pelajaran`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `walikelas`
--
ALTER TABLE `walikelas`
  ADD PRIMARY KEY (`kode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `walikelas`
--
ALTER TABLE `walikelas`
  MODIFY `kode` int(2) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
