<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	public function index()
	{
		$data['halaman']=("siswa/siswa");
		
		$data['datasiswa']=$this->mymodel->tampil("siswa");

		$this->load->view('beranda',$data);
	}
	
	public function tambah()
	{
		$data['halaman']=("siswa/tambah_siswa");
		$data['kdsiswa']=$this->mymodel->getID_auto("siswa","SI","id_siswa");

		$this->load->view('beranda',$data);
	}
	
	public function simpan(){
		$kd_siswa = $this->input->post('id_siswa');
		$nis = $this->input->post('nis');
		$nama = $this->input->post('nama');
		$tempat_lhr = $this->input->post('tempat_lhr');
		$tgllahir = $this->input->post('tgllahir');
		$agama = $this->input->post('agama');
		$jenis_kel = $this->input->post('jenis_kel');
		$alamat = $this->input->post('alamat');
		
		$data = array(
		'id_siswa'=>$kd_siswa,
		'nis'=>$nis,
		'nama'=>$nama,
		'tempat_lahir'=>$tempat_lhr,
		'tgl_lahir'=>$tgllahir,
		'agama'=>$agama,
		'jenis_kelamin'=>$jenis_kel,
		'alamat'=>$alamat
		);
		
		$this->mymodel->insert("siswa",$data);
		$this->session->set_flashdata('notifsiswa','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Well done!</strong> You successfully read <a class="alert-link" href="#">this important alert message</a>.</div></div></div>');
		redirect ("siswa");
	}
	
	function edit($kode){
		$where = array("id_siswa"=>$kode);
		$data['sis']=$this->mymodel->get_where("siswa",$where);
		
			$where = array("id_siswa"=>$kode);
			$data['sis'] = $this->mymodel->get_where("siswa",$where);
			$data['halaman']="siswa/edit-siswa";
			$this->load->view("beranda",$data);
	
	}
	
	function update(){
		$where=array("id_siswa"=>$this->input->post("id_siswa"));
		$ga = array(
		"nis"=>$this->input->post("nis"),
		"nama"=>$this->input->post("nama"),
		"tempat_lahir"=>$this->input->post("tempat_lhr"),
		"tgl_lahir"=>$this->input->post("tgllahir"),
		"agama"=>$this->input->post("agama"),
		"jenis_kelamin"=>$this->input->post("jenis_kel"),
		"alamat"=>$this->input->post("alamat")
		
		);
		$this->mymodel->update ("siswa",$ga,$where);
		$this->session->set_flashdata('notifsiswa','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Sukses!</strong> Data Berhasil Diupdate.</div></div></div>');
		redirect ("siswa/");
	}
	
	function hapus($h){
		$this->mymodel->hapus("siswa",array("id_siswa"=>$this->uri->segment(3)));
		$this->session->set_flashdata('notifsiswa','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Sukses!</strong> Data Berhasil Dihapus.</div></div></div>');
		redirect("siswa");
	}
	
	function detail($kode){
		$where = array("id_siswa"=>$kode);
		$data['sis']=$this->mymodel->get_where("siswa",$where);
		
			$where = array("id_siswa"=>$kode);
			$data['sis'] = $this->mymodel->get_where("siswa",$where);
			$data['halaman']="siswa/detail-siswa";
			$this->load->view("beranda",$data);
	
	}
}
