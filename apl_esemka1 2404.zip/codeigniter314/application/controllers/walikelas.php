<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Walikelas extends CI_Controller {

	public function index()
	{
		$data['halaman']=("walikelas/walikelas");
		

		$this->load->view('beranda',$data);
	}
	
	public function tambah()
	{
		$data['halaman']=("walikelas/tambah_walikelas");

		$this->load->view('beranda',$data);
	}
	
}
