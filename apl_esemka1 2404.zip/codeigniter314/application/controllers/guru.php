<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Guru extends CI_Controller {

	public function index()
	{
		$data['halaman']=("guru/guru");
		
		$data['dataguru']=$this->mymodel->tampil("guru");

		$this->load->view('beranda',$data);
	}
	
	public function tambah()
	{
		$data['halaman']=("guru/input-guru");
		$data['kdguru']=$this->mymodel->getID_auto("guru","GG","kode_guru");

		$this->load->view('beranda',$data);
	}
	
	public function simpan(){
		$kd_guru = $this->input->post('kode_guru');
		$nip = $this->input->post('nip');
		$nama = $this->input->post('nama');
		$tgllahir = $this->input->post('tgllahir');
		$jenis_kel = $this->input->post('jenis_kel');
		$agama = $this->input->post('agama');
		$pendidikan = $this->input->post('pendidikan');
		$no_tlp = $this->input->post('notlp');
		$alamat = $this->input->post('alamat');
		
		$data = array(
		'kode_guru'=>$kd_guru,
		'nip'=>$nip,
		'nama'=>$nama,
		'tgl_lahir'=>$tgllahir,
		'jenis_kelamin'=>$jenis_kel,
		'agama'=>$agama,
		'pendidikan'=>$pendidikan,
		'no_tlp'=>$no_tlp,
		'alamat'=>$alamat
		);
		
		$this->mymodel->insert("guru",$data);
		$this->session->set_flashdata('notifguru','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Well done!</strong> You successfully read <a class="alert-link" href="#">this important alert message</a>.</div></div></div>');
		redirect ("guru");
	}
	
}
