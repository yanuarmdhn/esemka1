<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelajaran extends CI_Controller {

	public function index()
	{
		$data['halaman']=("pelajaran/pelajaran");
		
		$data['datapelajaran']=$this->mymodel->tampil("pelajaran");

		$this->load->view('beranda',$data);
		
		
	}

	public function tambah()
	{
		$data['halaman']=("pelajaran/tambah_pelajaran");
		$data['kdpel']=$this->mymodel->getID_auto("pelajaran","PL","kd_pelajaran");

		$this->load->view('beranda',$data);
	}
	
	public function simpan(){
		
		$kd_pelajaran = $this->input->post('kode_pel');
		$m_pelajaran = $this->input->post('m_pelajaran');
		$kkm = $this->input->post('kkm');
		
		
		$data = array(
		'kd_pelajaran'=>$kd_pelajaran,
		'mata_pelajaran'=>$m_pelajaran,
		'kkm'=>$kkm
		);
		
		$this->mymodel->insert("pelajaran",$data);
		$this->session->set_flashdata('notifpel','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Sukses!</strong> Data Berhasil Dimasukkan.</div></div></div>');
		redirect ("pelajaran");
	}
	
	function hapus($h){
		$this->mymodel->hapus("pelajaran",array("kd_pelajaran"=>$this->uri->segment(3)));
		$this->session->set_flashdata('notifpel','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Sukses!</strong> Data Berhasil Dihapus.</div></div></div>');
		redirect("pelajaran");
	}
	
	function edit($kode){
		$where = array("kd_pelajaran"=>$kode);
		$data['pel']=$this->mymodel->get_where("pelajaran",$where);
		
			$where = array("kd_pelajaran"=>$kode);
			$data['pel'] = $this->mymodel->get_where("pelajaran",$where);
			$data['halaman']="pelajaran/edit-pelajaran";
			$this->load->view("beranda",$data);
	
	}
	
	function update(){
		$where=array("kd_pelajaran"=>$this->input->post("kode_pel"));
		$ga = array(
		"mata_pelajaran"=>$this->input->post("m_pelajaran"),
		"kkm"=>$this->input->post("kkm")
		
		);
		$this->mymodel->update ("pelajaran",$ga,$where);
		$this->session->set_flashdata('notifpel','<div class="col-lg-4"><div class="bs-component"><div class="alert alert-dismissible alert-success"><button class="close" type="button" data-dismiss="alert">×</button><strong>Sukses!</strong> Data Berhasil Diupdate.</div></div></div>');
		redirect ("pelajaran/");
	}
	
}