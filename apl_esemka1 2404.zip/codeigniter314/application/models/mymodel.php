<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mymodel extends CI_Model {
	
	function insert($tabel,$data)
	{	
	
	$this->db->insert($tabel,$data);
	
	}

	public function tampil($tabel)
	{
		$q=$this->db->get($tabel);
		return $q->result_array();
	}
	
	function getID_auto($tabel,$inisial,$MyField){
		$panjang  = 6 ;
		$sql = "select max(".$MyField.") as kode from ".$tabel;
		$query = $this->db->query($sql);
			foreach($query -> result() as $row ){
				$nilai =$row -> kode ;
			}
			
		if ($nilai==""){
		$angka=0;
		}else{
		$angka = substr($nilai, strlen($inisial));
		}

		$angka++;
		$angka   =strval($angka);
		$tmp  = "";
		for($i=1; $i<=($panjang-strlen($inisial)-strlen($angka)); $i++){
		$tmp=$tmp."0";
		}
		return $inisial.$tmp.$angka;

	}
	
	function update($tabel,$data,$where){
		
		$hasil=$this->db->update($tabel,$data,$where);
	
		
		
	}
	
	public function hapus($data,$where)
	{
		$q=$this->db->delete($data,$where);
	}

	function get_where($tabel,$where){
		
		$hasil=$this->db->get_where($tabel,$where);
		
		return $hasil;
		
		
		}
	
}
