
		<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-6">
                  <div class="well bs-component">
                    <form class="form-horizontal" method="post" action="<?php echo base_url();?>pelajaran/simpan">
                      <fieldset>
                        <legend>Entry Mata Pelajaran</legend>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Kode</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" value="<?php echo $kdpel;?>" name="kode_pel" readonly="readonly" type="text" placeholder="PL000*">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Mata Pelajaran</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" name="m_pelajaran" type="text" placeholder="Mata Pelajaran" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">KKM</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" name="kkm" type="number" placeholder="KKM" required>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-primary" name="simpan" type="submit">Submit</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<!-- Javascripts-->
    <script src="<?php echo base_url();?>template/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>template/js/essential-plugins.js"></script>
    <script src="<?php echo base_url();?>template/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>template/js/plugins/pace.min.js"></script>
    <script src="<?php echo base_url();?>template/js/main.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
	<script type="text/javascript">
      $('#sl').click(function(){
      	$('#tl').loadingBtn();
      	$('#tb').loadingBtn({ text : "Signing In"});
      });
      
      $('#el').click(function(){
      	$('#tl').loadingBtnComplete();
      	$('#tb').loadingBtnComplete({ html : "Sign In"});
      });
      
      $('#demoDate').datepicker({
      	format: "yyyy-mm-dd",
      	autoclose: true,
      	todayHighlight: true,
		orientation : "bottom"
      });
      
      $('#demoSelect').select2();
    </script>