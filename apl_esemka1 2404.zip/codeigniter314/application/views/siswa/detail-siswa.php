<?php foreach($sis->result_array() as $g) {?>
		<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
				<div class="col-lg-12">
                    <legend><h1 id="buttons">Biodata Siswa</h1></legend>
                </div>
                <div class="col-lg-6">
                  <div class="well bs-component">
                    <form class="form-horizontal" method="post" action="">
                      <fieldset>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="disabledInput">Kode Siswa</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="disabledInput" value="<?php echo $g['id_siswa'];?>" name="id_siswa" 
							readonly="readonly" type="text" placeholder="Kode">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Nama</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" value="<?php echo $g['nama'];?>" name="nama" type="text" readonly="readonly" placeholder="Nama">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Tempat Lahir</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" value="<?php echo $g['tempat_lahir'];?>" name="tempat_lhr" type="text" readonly="readonly" placeholder="Tempat">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Tanggal Lahir</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="demoDate" value="<?php echo $g['tgl_lahir'];?>" name="tgllahir" type="text" readonly="readonly" placeholder="Select Date">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Agama</label>
                          <div class="col-lg-10">
                            <input class="form-control" value="<?php echo $g['agama'];?>" name="agama" type="text" readonly="readonly">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Jenis Kelamin</label>
                          <div class="col-lg-10">
                            <input class="form-control" value="<?php echo $g['jenis_kelamin'];?>" name="jenis_kel" type="text" readonly="readonly">
                          </div>
                        </div>
						<div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
							<a class="btn btn-primary" href="<?php echo base_url();?>siswa/">Kembali</a>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
				<div class="col-lg-5">
                    <form class="form-horizontal" method="post" action="">
                      <fieldset>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">NIS</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" value="<?php echo $g['nis'];?>" name="nis" type="text" readonly="readonly" placeholder="NIS">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Jenis Kelamin</label>
                          <div class="col-lg-10">
                            <input class="form-control" value="<?php echo $g['jenis_kelamin'];?>" name="jenis_kel" type="text">
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Alamat</label>
                          <div class="col-lg-10">
                            <input class="form-control" value="<?php echo $g['alamat'];?>" name="alamat" type="text">
                          </div>
                        </div>
                      </fieldset>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </div>
		<!-- Javascripts-->
    <script src="<?php echo base_url();?>template/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>template/js/essential-plugins.js"></script>
    <script src="<?php echo base_url();?>template/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>template/js/plugins/pace.min.js"></script>
    <script src="<?php echo base_url();?>template/js/main.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
	<script type="text/javascript">
      $('#sl').click(function(){
      	$('#tl').loadingBtn();
      	$('#tb').loadingBtn({ text : "Signing In"});
      });
      
      $('#el').click(function(){
      	$('#tl').loadingBtnComplete();
      	$('#tb').loadingBtnComplete({ html : "Sign In"});
      });
      
      $('#demoDate').datepicker({
      	format: "yyyy-mm-dd",
      	autoclose: true,
      	todayHighlight: true,
		orientation : "bottom"
      });
      
      $('#demoSelect').select2();
    </script>
<?php } echo form_close();?>