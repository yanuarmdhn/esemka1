
		<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="row">
                <div class="col-lg-6">
                  <div class="well bs-component">
                    <form class="form-horizontal" method="post" action="<?php echo base_url();?>siswa/simpan">
                      <fieldset>
                        <legend>Entry Data Siswa</legend>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="disabledInput">Kode Siswa</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="disabledInput" value="<?php echo $kdsiswa;?>" name="id_siswa" 
							readonly="readonly" type="text" placeholder="Kode" required>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">NIS</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" value="" name="nis" type="number" placeholder="NIS" required>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Nama</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" name="nama" type="text" placeholder="Nama" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Tempat Lahir</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="inputEmail" name="tempat_lhr" type="text" placeholder="Tempat" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="inputEmail">Tanggal Lahir</label>
                          <div class="col-lg-10">
                            <input class="form-control" id="demoDate" name="tgllahir" type="text" placeholder="Select Date" required>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="select">Agama</label>
                          <div class="col-lg-10">
                            <select class="form-control" name="agama"id="select">
                              <option>Islam</option>
                              <option>Katolik</option>
							  <option>Kristen Protestan</option>
                              <option>Hindu</option>
                              <option>Budha</option>
                            </select>
                          </div>
                        </div>
						<div class="form-group">
                          <label class="col-lg-2 control-label" for="select">Jenis Kelamin</label>
                          <div class="col-lg-10">
                            <select class="form-control" name="jenis_kel"id="select">
                              <option>Laki - Laki</option>
                              <option>Perempuan</option>
                            </select>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-lg-2 control-label" for="textArea">Alamat</label>
                          <div class="col-lg-10">
                            <textarea class="form-control" id="textArea" name="alamat" rows="3" required></textarea><span class="help-block"></span>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button class="btn btn-primary" name="simpan" type="submit">Submit</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
		<!-- Javascripts-->
    <script src="<?php echo base_url();?>template/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>template/js/essential-plugins.js"></script>
    <script src="<?php echo base_url();?>template/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>template/js/plugins/pace.min.js"></script>
    <script src="<?php echo base_url();?>template/js/main.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/bootstrap-datepicker.min.js"></script>
	<script type="text/javascript">
      $('#sl').click(function(){
      	$('#tl').loadingBtn();
      	$('#tb').loadingBtn({ text : "Signing In"});
      });
      
      $('#el').click(function(){
      	$('#tl').loadingBtnComplete();
      	$('#tb').loadingBtnComplete({ html : "Sign In"});
      });
      
      $('#demoDate').datepicker({
      	format: "yyyy-mm-dd",
      	autoclose: true,
      	todayHighlight: true,
		orientation : "bottom"
      });
      
      $('#demoSelect').select2();
    </script>
	<script>
	$.validator.setDefaults({
		submitHandler: function() {
			alert("submitted!");
		}
	});

	$().ready(function() {
		// validate the comment form when it is submitted
		$("#commentForm").validate();

		// validate signup form on keyup and submit
		$("#signupForm").validate({
			rules: {
				firstname: "required",
				lastname: "required",
				username: {
					required: true,
					minlength: 2
				},
				password: {
					required: true,
					minlength: 5
				},
				confirm_password: {
					required: true,
					minlength: 5,
					equalTo: "#password"
				},
				email: {
					required: true,
					email: true
				},
				topic: {
					required: "#newsletter:checked",
					minlength: 2
				},
				agree: "required"
			},
			messages: {
				firstname: "Please enter your firstname",
				lastname: "Please enter your lastname",
				username: {
					required: "Please enter a username",
					minlength: "Your username must consist of at least 2 characters"
				},
				password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long"
				},
				confirm_password: {
					required: "Please provide a password",
					minlength: "Your password must be at least 5 characters long",
					equalTo: "Please enter the same password as above"
				},
				email: "Please enter a valid email address",
				agree: "Please accept our policy",
				topic: "Please select at least 2 topics"
			}
		});

		// propose username by combining first- and lastname
		$("#username").focus(function() {
			var firstname = $("#firstname").val();
			var lastname = $("#lastname").val();
			if (firstname && lastname && !this.value) {
				this.value = firstname + "." + lastname;
			}
		});

		//code to hide topic selection, disable for demo
		var newsletter = $("#newsletter");
		// newsletter topics are optional, hide at first
		var inital = newsletter.is(":checked");
		var topics = $("#newsletter_topics")[inital ? "removeClass" : "addClass"]("gray");
		var topicInputs = topics.find("input").attr("disabled", !inital);
		// show when newsletter is checked
		newsletter.click(function() {
			topics[this.checked ? "removeClass" : "addClass"]("gray");
			topicInputs.attr("disabled", !this.checked);
		});
	});
	</script>