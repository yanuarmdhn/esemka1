<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>template/css/main.css">
    <title>Esemka1</title>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries-->
    <!--if lt IE 9
    script(src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js')
    script(src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js')
    -->
  </head>
  <body class="sidebar-mini fixed">
    <div class="wrapper">
      <!-- Navbar-->
      <header class="main-header hidden-print"><a class="logo" href="">Esemka1</a>
        <nav class="navbar navbar-static-top">
          <!-- Sidebar toggle button--><a class="sidebar-toggle" href="#" data-toggle="offcanvas"></a>
          <!-- Navbar Right Menu-->
          <div class="navbar-custom-menu">
            <ul class="top-nav">
              <!--Notification Menu-->
              
              <!-- User Menu-->
              <li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu">
                  <li><a href="<?php echo base_url();?>logout"><i class="fa fa-sign-out fa-lg"></i>Logout</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Side-Nav-->
      <aside class="main-sidebar hidden-print">
        <section class="sidebar">
          <div class="user-panel">
            <div class="pull-left image"><img class="img-circle" src="http://localhost/codeigniter314/photo/48.jpg" alt="User Image"></div>
            <div class="pull-left info">
              <p>Yanuar R</p>
              <p class="designation">New</p>
            </div>
          </div>
          <!-- Sidebar Menu-->
          <ul class="sidebar-menu">
            <li class=""><a href="<?php echo base_url();?>dashboard"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
			<li><a href="<?php echo base_url();?>siswa"><i class="fa fa-group"></i><span>Siswa</span></a></li>
			<li><a href="<?php echo base_url();?>pelajaran"><i class="fa fa-th-list"></i><span>Pelajaran</span></a></li>
			<li><a href="<?php echo base_url();?>guru"><i class="fa fa-user"></i><span>Guru</span></a></li>
			<li><a href="<?php echo base_url();?>walikelas"><i class="fa fa-user"></i><span>Wali Kelas</span></a></li>
          </ul>
        </section>
      </aside>
      <div class="content-wrapper">
        <?php $this->load->view($halaman); ?>
      </div>
    </div>
    <!-- Javascripts-->
    <script src="<?php echo base_url();?>template/js/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url();?>template/js/jquery.validate.js"></script>
    <script src="<?php echo base_url();?>template/js/jquery.validate.min.js"></script>
    <script src="<?php echo base_url();?>template/js/essential-plugins.js"></script>
    <script src="<?php echo base_url();?>template/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>template/js/plugins/pace.min.js"></script>
    <script src="<?php echo base_url();?>template/js/main.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/chart.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/jquery.vmap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/jquery.vmap.world.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/plugins/jquery.vmap.sampledata.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){
      	var data = {
      		labels: ["January", "February", "March", "April", "May"],
      		datasets: [
      			{
      				label: "My First dataset",
      				fillColor: "rgba(220,220,220,0.2)",
      				strokeColor: "rgba(220,220,220,1)",
      				pointColor: "rgba(220,220,220,1)",
      				pointStrokeColor: "#fff",
      				pointHighlightFill: "#fff",
      				pointHighlightStroke: "rgba(220,220,220,1)",
      				data: [65, 59, 80, 81, 56]
      			},
      			{
      				label: "My Second dataset",
      				fillColor: "rgba(151,187,205,0.2)",
      				strokeColor: "rgba(151,187,205,1)",
      				pointColor: "rgba(151,187,205,1)",
      				pointStrokeColor: "#fff",
      				pointHighlightFill: "#fff",
      				pointHighlightStroke: "rgba(151,187,205,1)",
      				data: [28, 48, 40, 19, 86]
      			}
      		]
      	};
      	var ctxl = $("#lineChartDemo").get(0).getContext("2d");
      	var lineChart = new Chart(ctxl).Line(data);
      
      	var map = $('#demo-map');
      	map.vectorMap({
      		map: 'world_en',
      		backgroundColor: '#fff',
      		color: '#333',
      		hoverOpacity: 0.7,
      		selectedColor: '#666666',
      		enableZoom: true,
      		showTooltip: true,
      		scaleColors: ['#C8EEFF', '#006491'],
      		values: sample_data,
      		normalizeFunction: 'polynomial'
      	});
      });
    </script>
  </body>
</html>