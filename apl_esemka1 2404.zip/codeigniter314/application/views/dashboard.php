<div class="page-title">
          <div>
            <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
          </div>
 </div>
 <div class="card">
        <h3 class="card-title">Getting Started</h3>
        <p style="font-size: 16px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam tempor nulla a fringilla blandit. Sed consectetur lorem vel nibh elementum sodales. Mauris luctus euismod orci a tincidunt. Aliquam consectetur vel mi et volutpat. Fusce eget ante porttitor, interdum lorem non, faucibus purus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus nec arcu nisi. Nunc mattis posuere lorem ut aliquam. Nullam et semper sapien.
		Nullam tincidunt, magna non facilisis varius, lorem ex fermentum diam, sit amet tristique augue eros vel lacus. Mauris feugiat, arcu id ornare blandit, sem magna auctor tellus, nec condimentum felis mauris sed libero. Praesent quis dapibus libero. Ut sed nibh lorem. Sed tristique erat ac libero iaculis egestas at sed orci. Morbi fermentum lacus mi, ut fringilla odio dapibus at. Donec finibus iaculis dui, sit amet fermentum tortor congue vel. Sed eget lobortis urna. Ut fringilla fermentum libero, vel luctus nunc posuere vitae. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tristique egestas turpis, at dapibus justo vehicula in.</p>
              <p class="mt-40 mb-20">
			  <a class="btn btn-primary icon-btn mr-10" href="<?php echo base_url();?>siswa"><i class="fa fa-file"></i>Siswa</a>
			  <a class="btn btn-info icon-btn mr-10" href="<?php echo base_url();?>pelajaran"><i class="fa fa-github"></i>Pelajaran</a>
			  <a class="btn btn-success icon-btn" href="#"><i class="fa fa-download"></i>Nilai</a>
			  </p>
            </div>